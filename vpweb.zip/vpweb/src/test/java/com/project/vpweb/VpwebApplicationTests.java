package com.project.vpweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VpwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
